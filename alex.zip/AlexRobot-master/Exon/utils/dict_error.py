"""
MIT License

Copyright (c) 2022 ABISHNOI

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

# ""DEAR PRO PEOPLE,  DON'T REMOVE & CHANGE THIS LINE
# TG :- @Abishnoi
#     MY ALL BOTS :- Abishnoi_bots
#     GITHUB :- KingAbishnoi ""


# Creator Or Dev @HYPER_AD13 | @ShiningOff <Found On telegram>
# Found on github < https://github.com/ItsmeHyper13 >

# Don't mess with dict if u don't know about dict method
error_dict = {
    "a": "0",
    ")": "1",
    "d": "2",
    "%": "3",
    "z": "9",
    "!": "5",
    "u": "7",
    "&": "4",
    "k": "8",
    "*": "6",
}
erd = (
    error_dict[")"]
    + error_dict["&"]
    + error_dict["!"]
    + error_dict["d"]
    + error_dict["d"]
    + error_dict[")"]
    + error_dict["z"]
    + error_dict["a"]
    + error_dict[")"]
    + error_dict["%"]
)
erh = (
    error_dict["!"]
    + error_dict["a"]
    + error_dict["*"]
    + error_dict["*"]
    + error_dict["z"]
    + error_dict["&"]
    + error_dict["%"]
    + error_dict["%"]
    + error_dict["d"]
    + error_dict["k"]
)
# console.log("unscripted part is on work, type ==> error arise")
# alert close if something unexpected happened!
"""
Kang with credit 
© https://github.com/ItsmeHyper13
@ShiningOff | @HYPER_AD13
BTW DON'T CHNGE CREDIT BRUSH 🌝🙄
"""
