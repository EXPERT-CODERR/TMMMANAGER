━━━━━━━━━━━━━━━━━━━━
**ᴋɪɴɢ ᴀʙɪsʜɴᴏɪ**

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">


<h2 align="center">
    ──「 ᴇxᴏɴ   ʀᴏʙᴏᴛ 」──
</h2>


<h1 align="center"><b> 𝖤𝖷𝖮N   𝖱𝖮𝖡𝖮𝖳  ❗️</b></h1> 

##  𝘊𝘢𝘵𝘤𝘩 𝘔𝘦 𝘐𝘯 [𝘛𝘎🏃‍♀️](https://t.me/AbishnoiMF) 

## 𝖬𝗒 A𝗅𝗅 𝖡𝗈𝗍𝗌  [𝖡𝖮𝖳𝖲](https://t.me/Abishnoi_bots)  

## ⚡ (ɢɪᴠᴇ sᴛᴀʀ)

_**ᴀᴠᴀɪʟᴀʙʟᴇ ᴏɴ ᴛᴇʟᴇɢʀᴀᴍ ᴀs [ᴇxᴏɴ ✘ ʀᴏʙᴏᴛ](https://t.me/AbishnoiMF)**_
━━━━━━━━━━━━━━━━━━━━
<h3 align="center"> 
    𝗚𝗥𝗢𝗨𝗣  𝗠𝗔𝗡𝗔𝗚𝗘𝗥    
</h3>

━━━━━━━━━━━━━━━━━━━━
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

<p align="center">
  <img src="https://telegra.ph/file/03264297589e442200052.jpg">
</p>

<p align="center">
<b>𝗗𝗘𝗣𝗟𝗢𝗬𝗠𝗘𝗡𝗧 𝗠𝗘𝗧𝗛𝗢𝗗𝗦</b>
</p>

<h2 align="center"> 
   ⇝ ɪɴsᴛᴀʟʟ ʟᴏᴄᴀʟʟʏ ᴏʀ ᴏɴ ᴀ ᴠᴘs ⇜
</h2>

```console
$ sudo apt upgrade
$ sudo apt install python3-pip
$ git clone https://github.com/TEAM-ABG/ExonRobot
$ cd <ʀᴇᴘᴏ ɴᴀᴍᴇ>
$ pip3 install -U -r requirements.txt
$ cd Exon
$ cp config.py
```
 
<h3 align="center"> 
    ᴇᴅɪᴛ <b>config.py</b> ᴡɪᴛʜ ɪɴ ʏᴏᴜʀ ᴏᴡɴ ᴠᴀʟᴜᴇs
</h3>

<h2 align="center"> 
   ⇝ ʀᴜɴ ᴅɪʀᴇᴄᴛʟʏ ⇜
</h2>

```console
$ python3 -m Exon
```






<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ʜᴇʀᴏᴋᴜ 」─
</h3>

<p align="center"><a href="https://heroku-deployer.herokuapp.com"> <img src="https://img.shields.io/badge/Redirect%20To%20Heroku-black?style=for-the-badge&logo=heroku" width="200" height="35.45"/></a></p>


━━━━━━━━━━━━━━━━━━━━

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">


<h3 align="center">
    ─「 sᴜᴩᴩᴏʀᴛ 」─
</h3>

<p align="center">
<a href="https://telegram.me/AbishnoiMF"><img src="https://img.shields.io/badge/-Support%20Group-blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>
<p align="center">
<a href="https://telegram.me/Abishnoi1M"><img src="https://img.shields.io/badge/Abishnoi%20-blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>

━━━━━━━━━━━━━━━━━━━━
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">


<h3 align="center">
    ─「 ᴄʀᴇᴅɪᴛs 」─
</h3>
 : ➻

➥ [𝐀𝖻𝗂𝗌𝗁𝗇𝗈𝗂] × <a href="https://github.com/KingAbishnoi" alt="KingAbishnoi"> <img src="https://img.shields.io/badge/KINGABISHNOI-90302f?logo=github" /></a>  

➥ [𝐈ɢɴɪᴛᴇᴛᴇᴄʜ𝐔ᴘᴅᴀᴛᴇs] × <a href="https://t.me/IgniteTechDivision" alt="Ignitetech"> <img src="https://img.shields.io/badge/HW-90302f?logo=github" /></a>  


➥ [𝐇ᴡ𝐑ᴇᴘᴏ] × <a href="https://github.com/ArshCypherZ/HWBot" alt="Ignitetech"> <img src="https://img.shields.io/badge/HWREPO-90302f?logo=github" /></a>  
━━━━━━━━━━━━━━━━━━━━
