HELP_IMG = ["https://telegra.ph/file/2ad7c9d508b26c3cc7c09.jpg"]

START_IMG = ["https://telegra.ph/file/2ad7c9d508b26c3cc7c09.jpg"]


PHOTO = ["https://telegra.ph/file/2ad7c9d508b26c3cc7c09.jpg"]
